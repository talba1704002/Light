package com.talha.light.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Full-screen WebView shell for the ESP32 light controller.
 * The HTML UI lives on the ESP32 itself (it is served from the board), so the app
 * simply opens the board's address in a borderless full-screen WebView.
 */
public class WebViewActivity extends Activity {

        private static final String BASE_URL = "http://esplight.local/";
    private static final long MIN_SPLASH_MS = 1500;
    private static final long WIFI_WAIT_MS = 2500;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView web;
    private View splash;
    private View errorView;
    private TextView errorText;

    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private boolean started = false;
    private boolean pageFailed = false;
    private long splashShownAt;
    private boolean splashHidden = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        splashShownAt = System.currentTimeMillis();

        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        buildErrorView();
        errorView.setVisibility(View.GONE);
        root.addView(errorView, new FrameLayout.LayoutParams(-1, -1));

        buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        goImmersive();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptCookie(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String host = Uri.parse(currentBase()).getHost();
                if (u.getHost() != null && host != null && !u.getHost().equals(host)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                pageFailed = false;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                CookieManager.getInstance().flush();
                if (!pageFailed) {
                    errorView.setVisibility(View.GONE);
                    hideSplash();
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    pageFailed = true;
                    showError("Can't reach the light controller at\nhttp://esplight.local/"
                            + "\n\nMake sure your phone is on the same Wi-Fi\nas the controller. Retrying automatically…");
                    handler.postDelayed(autoRetry, 4000);
                }
            }
        });

        // Native dialogs so alert()/confirm() in the page work
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(WebViewActivity.this)
                        .setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });

        bindToWifiThenLoad();
    }

    // ---------- networking ----------

    /** Android may send traffic over mobile data when the ESP Wi-Fi has no internet.
     *  Bind this app to the Wi-Fi network so http://esplight.local always goes through Wi-Fi. */
    private void bindToWifiThenLoad() {
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            NetworkRequest req = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network n) {
                    try { cm.bindProcessToNetwork(n); } catch (Exception ignored) {}
                    handler.post(WebViewActivity.this::startLoad);
                }
            };
            cm.requestNetwork(req, netCb);
        } catch (Exception e) {
            startLoad();
            return;
        }
        handler.postDelayed(this::startLoad, WIFI_WAIT_MS); // no Wi-Fi? try anyway
    }

    private void startLoad() {
        if (started) return;
        started = true;
        web.loadUrl(currentBase());
    }

    private final Runnable autoRetry = new Runnable() {
        @Override public void run() {
            if (pageFailed && !isFinishing()) reload();
        }
    };

    private void reload() {
        handler.removeCallbacks(autoRetry);
        pageFailed = false;
        errorView.setVisibility(View.GONE);
        showSplashAgain();
        web.loadUrl(currentBase());
    }

    /** The app ALWAYS talks to the controller by name, never by IP. */
    private String currentBase() {
        return BASE_URL;
    }

    // ---------- UI pieces ----------

    private void buildSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.BLACK);
        f.setClickable(true);
        // Vector logo (res/drawable/splash_logo.xml): scales to any screen with no blur/stretch.
        // Padding is recalculated on every size change so it also fits when rotated.
        ImageView iv = new ImageView(this) {
            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                int side = Math.min(w, h);
                int padX = (w - Math.round(side * 0.40f)) / 2;
                int padY = (h - Math.round(side * 0.40f * 470f / 357f)) / 2;
                setPadding(padX, padY, padX, padY);
            }
        };
        iv.setImageResource(R.drawable.splash_logo);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        splash = f;
    }

    private void buildErrorView() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.BLACK);
        int p = dp(28);
        l.setPadding(p, p, p, p);

        errorText = new TextView(this);
        errorText.setTextColor(Color.WHITE);
        errorText.setTextSize(16);
        errorText.setGravity(Gravity.CENTER);
        l.addView(errorText, new LinearLayout.LayoutParams(-1, -2));

        l.addView(makeBtn("Retry", v -> reload()));
        errorView = l;
    }

    private Button makeBtn(String t, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setOnClickListener(c);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void showError(String msg) {
        errorText.setText(msg);
        errorView.setVisibility(View.VISIBLE);
        hideSplash();
    }

    private void hideSplash() {
        if (splashHidden) return;
        long wait = MIN_SPLASH_MS - (System.currentTimeMillis() - splashShownAt);
        handler.postDelayed(() -> {
            splashHidden = true;
            splash.animate().alpha(0f).setDuration(350)
                    .withEndAction(() -> splash.setVisibility(View.GONE)).start();
        }, Math.max(0, wait));
    }

    private void showSplashAgain() {
        // Only used on retry: keep it simple, show splash instantly
        splashHidden = false;
        splashShownAt = System.currentTimeMillis();
        splash.animate().cancel();
        splash.setAlpha(1f);
        splash.setVisibility(View.VISIBLE);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- full screen ----------

    @SuppressWarnings("deprecation")
    private void goImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    // ---------- lifecycle ----------

    @Override
    public void onBackPressed() {
        if (errorView.getVisibility() != View.VISIBLE && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { if (netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) {}
        try { cm.bindProcessToNetwork(null); } catch (Exception ignored) {}
        ((ViewGroup) root).removeView(web);
        web.destroy();
        super.onDestroy();
    }
}
