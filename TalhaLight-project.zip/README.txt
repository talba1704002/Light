Talha Light - full-screen WebView app for the ESP32 light controller

1. Create a new GitHub repo and upload EVERYTHING from this zip (keep the folder structure,
   including the hidden ".github" folder).
2. Go to the repo > Actions > "Build Android APK" (runs on every push, or press "Run workflow").
3. When it finishes, open the run and download the artifact "TalhaLight-apk" -> TalhaLight.apk
4. Install on the phone (allow "install unknown apps").

The app ALWAYS opens http://esplight.local/ (never an IP address). If the controller is not
reachable it shows a Retry screen and retries automatically every few seconds.
Package: com.talha.light.app

Logo: the TALHA logo is a vector (app/src/main/res/drawable/splash_logo.xml, and talha_logo.svg
in the project root), so it never blurs or stretches on any screen size.
